exp_dev.txt and exp_text.tet contain examples of unlabeled cases in the development set and test set respectively.
The full set would be released upon acceptance.